// used so that accessories outside the widget can still be tapped
@interface HSWidgetUnclippedView : UIView
@end
