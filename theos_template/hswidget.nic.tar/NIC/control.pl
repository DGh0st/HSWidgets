NIC->variable("KILL_RULE") = "after-install::\n\tinstall.exec \"killall -9 SpringBoard\"";
