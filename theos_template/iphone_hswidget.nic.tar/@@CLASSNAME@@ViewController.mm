#import "@@CLASSNAME@@ViewController.h"

@implementation @@CLASSNAME@@ViewController
-(void)viewDidLoad {
	[super viewDidLoad];

	// add custom view
}

+(HSWidgetSize)minimumSize {
	return HSWidgetSizeMake(1, 1); // least amount of rows and cols the widget needs
}
@end
