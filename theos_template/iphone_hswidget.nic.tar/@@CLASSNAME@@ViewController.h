#import <HSWidgets/HSWidgetViewController.h>

@interface @@CLASSNAME@@ViewController : HSWidgetViewController
@end

